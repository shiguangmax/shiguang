package cn.hisoft.daoImpl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import cn.hisoft.Utils.JDBCUtils;
import cn.hisoft.dao.SearchProductDao;
import cn.hisoft.domain.Product;

public class SearchProductDaoImpl implements SearchProductDao {

	QueryRunner runner=new QueryRunner(JDBCUtils.getDataSource());
	
	@Override
	public List<Product> queryProduct(Product product) {
		
		String sql="SELECT p.* FROM product AS p WHERE name LIKE ? OR category LIKE ? ";
		
		try {
			return runner.query(sql, new BeanListHandler<Product>(Product.class),"%"+product.getName()+"%","%"+product.getCategory()+"%");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

}
