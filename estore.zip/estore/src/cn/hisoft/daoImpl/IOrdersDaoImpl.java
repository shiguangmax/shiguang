package cn.hisoft.daoImpl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import cn.hisoft.Utils.JDBCUtils;
import cn.hisoft.dao.IOrdersDao;
import cn.hisoft.domain.Orders;
import cn.hisoft.domain.Product;


public class IOrdersDaoImpl implements IOrdersDao {

	QueryRunner runner=new QueryRunner(JDBCUtils.getDataSource());
	
	
	@Override
	public List<Orders> allOrdersInformation(String user_id) {
		try {
			String sql="SELECT o.* FROM orders as o WHERE o.user_id=?";
			return runner.query(sql, new BeanListHandler<Orders>(Orders.class),user_id);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	
	@Override
	public Map<String, List<Product>> allProductInformationByOrders(List<Orders> ordersList) {
		HashMap<String, List<Product>> map=new HashMap<String, List<Product>>();
		String sql="select p.* FROM product as p WHERE p.id=(SELECT oi.product_id FROM orderitem as oi where oi.orders_id=?)";
		for (Orders orders : ordersList) {
			try {
				List<Product> queryProduct = runner.query(sql, new BeanListHandler<Product>(Product.class),orders.getId());
				map.put(orders.getId(), queryProduct);
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException();
			}
		}
		return map;
	}

	
	@Override
	public void deleteOrderByOrderId(String order_id) {
		String sql="delete from orders where id=?";
		try {
			runner.update(sql,order_id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
