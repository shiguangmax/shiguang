package cn.hisoft.daoImpl;


import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;


import cn.hisoft.Utils.JDBCUtils;
import cn.hisoft.dao.ILoginDao;
import cn.hisoft.domain.User;

public class LoginDaoImpl implements ILoginDao {

	@Override
	public User queryUserById(User user) {
		try {
			QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
			String sql ="select * from user where tel =? and password = ?";
			return runner.query(sql, new BeanHandler<User>(User.class), user.getTel(),user.getPassword());
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("登录查询失败");
		}
	}

}
