package cn.hisoft.daoImpl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import cn.hisoft.dao.ISelectCartDao;
import cn.hisoft.Utils.JDBCUtils;
import cn.hisoft.domain.Orders;
import cn.hisoft.domain.Product;
import cn.hisoft.domain.buycar;
import cn.hisoft.domain.buycarProduct;

public class SelectCartDaoImpl implements ISelectCartDao {

	private static final ResultSetHandler<String> BeanHandler = null;

	@Override
	public List<buycarProduct> selectCart(String id) {
		try {
			QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
			String sql = "select * from product,buycar where buycar.productid=product.id and buycar.user_id=?";
			return  runner.query(sql,new BeanListHandler<buycarProduct>(buycarProduct.class),id);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e+"查看购物车错误");
		}
	}

	@Override
	public void delCart(String id) {
		try {
			QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
			String sql = "delete from buycar where productid=?";
			runner.update(sql,id);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e+"删除错误");
		}
	}

	@Override
	public List<Product> selectProduct() {
			try {
				QueryRunner runner =new QueryRunner(JDBCUtils.getDataSource());
				String sql="select * from product";
				return runner.query(sql, new BeanListHandler<Product>(Product.class));
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e+"查询所有商品失败");
			}
	}

	@Override
	public Product selectOneProduct(String productid) {
		try {
			QueryRunner runner =new QueryRunner(JDBCUtils.getDataSource());
			String sql="select * from product where id=?";
			return runner.query(sql, new BeanHandler<Product>(Product.class),productid);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e+"查询单个商品失败");
		}
	}

	@Override
	public void buyProduct(String user_id, String productid) {
		try {
			QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
			String sql = "insert into buycar(user_id,productid,buynum) value(?,?,1)";
			runner.update(sql, user_id,productid);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e+"添加商品到购物车");
		}
	}

	@Override
	public buycar buySelectProduct(String user_id, String productid) {
		try {
			QueryRunner runner =new QueryRunner(JDBCUtils.getDataSource());
			String sql="select * from buycar where user_id=? and productid=?  ";
			return runner.query(sql, new BeanHandler<buycar>(buycar.class),user_id,productid);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e+"查询购物车商品重复失败");
		}
	}

	@Override
	public void buyProductNum(String user_id, String productid) {
		try {
			QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
			String sql = "update buycar set buynum=buynum+1 where productid=? and user_id=?";
			runner.update(sql,productid ,user_id);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e+"添加购物车物品数量失败");
		}
	}

	@Override
	public int buildorder(List<buycarProduct> list, Orders order) {
		try {
			QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
			String sql = "insert into orders values(?,?,?,?,?,?)";
			return runner.update(sql, order.getId(),order.getTotalprice(),order.getReceiverinfor(),order.getPaystate(),order.getCreatetime(),order.getUser_id());
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e+"生成订单失败");
		}
	}

	@Override
	public void addOrderItem(String id, buycarProduct orderitem) {
			try {
				QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
				String sql = "insert into orderitem values(?,?,?)";
				runner.update(sql, id,orderitem.getProductid(),orderitem.getBuynum());
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e+"添加中间表错误");
			}

	}

	@Override
	public void delAllCart(String user_id) {
		try {
			QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
			String sql = "delete from buycar where user_id=? ";
			runner.update(sql, user_id);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e+"生成订单后清空购物车失败");
		}
	}
}
