package cn.hisoft.daoImpl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import cn.hisoft.Utils.JDBCUtils;
import cn.hisoft.dao.ProductAddDao;
import cn.hisoft.domain.Product;



public class ProductAddDaoImpl  implements ProductAddDao{

	@Override
	public boolean ProductAddDao(Product product) { //添加数据
		
		try {
			QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
			String sql = "insert into product values(?,?,?,?,?,?,?,?);";
			int productAdd = runner.update(sql,product.getId(),product.getName(),product.getCategory(),product.getMarketprice(),product.getEstoreprice(),product.getPnum(), product.getImgurl(),product.getDescription());
				if(productAdd>0){
					return true;
				}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e + "添加失败");
		}
		return false;
	}

	@Override
	public List<Product> selectDaoShangpin() { // 查询所有商品
		
		try {
			QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
			String sql = "select*from product";
			return runner.query(sql, new BeanListHandler<Product>(
					Product.class));
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e + "查询所有失败");
		}
	}
	
	
	public Product findAllCustomerById(String id) { //根据id做修改的回显-商品详情
		
		
		try {
			QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
			String sql = "select * from product where id = ?";
			return runner.query(sql, new BeanHandler<Product>(Product.class),id);
			
		
		} catch (SQLException e) {

			e.printStackTrace();
			throw new RuntimeException(e + "根据id做修改的回显失败");
		}

		
		
	}

	@Override
	public long getTotalCounts() { //分页
		try {
			QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
			String sql ="select count(1) from product";
			return (Long) runner.query(sql, new ScalarHandler(1));
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e+"查询总条数失败！");
		}
	}

	@Override
	public List<Product> getCustomers(int startIndex, int pageSize) { //分页
		try {
			QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
			String sql ="select * from product limit ?,?";
			return runner.query(sql, new BeanListHandler<Product>(Product.class),startIndex,pageSize);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e+"分页失败！");
		}
	}
	
	
	
	
	/*
	 * 商品分类查询
	 * 不成功 项目便当爸咯
	 * 
	 */
	
	public long getTotalCountsFenYe(Product product) { //获取分类商品总条数分页
		try {
		
			QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
			String sql ="select count(1) from product where category = ?;";
			return (Long) runner.query(sql, new ScalarHandler(1),product.getCategory());
		} catch (SQLException e) { 
			e.printStackTrace();
			throw new RuntimeException(e+"查询总条数失败！");
		}
	}
	
	
	public List<Product> getCustomersFenYe(int startIndex, int pageSize,Product product) { //分类商品分页 
		try {
			
			QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
			String sql ="select * from product where category = ? limit ?,?";
			return runner.query(sql, new BeanListHandler<Product>(Product.class),product.getCategory(),startIndex,pageSize);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e+"分页失败！");
		}
	}




	
	
	
	
	
	
	
	
	
	

}
