package cn.hisoft.daoImpl;



import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;


import cn.hisoft.Utils.JDBCUtils;
import cn.hisoft.dao.IRegistDao;
import cn.hisoft.domain.User;
/*
 * 许冠辉
 */
public class RegistDaoImpl implements IRegistDao {

	@Override
	public void regist(User user) {
		try {
			QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
			String sql = "insert into user values(?,?,?,?,?,?)";
			runner.update(sql, user.getId(), user.getTel(), user.getPassword(),user.getNickname(),user.getRole(), user.getActive());
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e + "注册失败");
		}
	}

	@Override
	public User queryUserBytel(User user) {
		try {
			QueryRunner runner = new QueryRunner(JDBCUtils.getDataSource());
			String sql = "select * from user where tel = ?";
			return runner.query(sql, new BeanHandler<User>(User.class),user.getTel());
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e + "用户已存在");
		}
		
	}
}
