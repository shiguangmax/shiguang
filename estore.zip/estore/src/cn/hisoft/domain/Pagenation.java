package cn.hisoft.domain;

import java.util.List;

/**
 * 对象 分页请求和响应实体 TO
 * 
 * @author Administrator 对象业务层封装 提供setter 计算的数据 可以直接提供getter 计算出来
 */
public class Pagenation {
	
	private int pageNum = 1;// 当前页码 每一次请求 来自 web 接受请求
	private int pageSize = 3;// 每页显示记录数 固定不动
	private int totalPages;// 总页码 计算出来 : 总记录数 和 每页显示记录数
	private int beforePage;// 上一页 当前页码 -1
	private int nextPage;// 下一页 当前页码+1
	private int pageBar[];// 每次查询 分页栏每一个显示页码 6----15 计算出来 总页码+当前页码计算出来
	private List<Product> customers;// 每一次查询 分页记录数 // 数据库查询 select * from xxx limit ?,?
	private long totalCounts;// 总记录数 // 来自数据查询 ...业务层封装
	private int startIndex;// 分页查询的起始记录数

	public int getStartIndex() {
		this.startIndex = (this.pageNum - 1) * this.pageSize;
		return this.startIndex;// 计算出分页查询的起始记录数
	}

	public int getPageNum() {
		return pageNum;
	}

	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * 总页码
	 * 有多少条数据可以显示出多少页，每页显示10条
	 * @return
	 */
	public int getTotalPages() {
		//137 + 9 = 146 = 14   137 == 14页
		this.totalPages = ((int) this.totalCounts + (this.pageSize - 1)) / this.pageSize;
		return this.totalPages;
	}

	/*
	 * 上一页
	 */
	public int getBeforePage() {
		this.beforePage = this.pageNum - 1;
		if (this.beforePage <= 0) {
			this.beforePage = 1;
		}
		return this.beforePage;
	}

	// 下一页
	public int getNextPage() {
		this.nextPage = this.pageNum + 1;
		if (this.nextPage >= this.totalPages) {
			this.nextPage = this.totalPages;
		}
		return this.nextPage;
	}

	/*
	 * 页码栏数值 6---15
	 */
	public int[] getPageBar() {
		// 由当前页码 总页码 计算 规则 前五后四规则 基于 总页码>10 每次显示10个页码
		// 计算起始页码 数字 以及 末尾 页码数字
		int beginPage;// 起始页码 6 11
		int endPage;// 末尾数字 15
		// 1: 如果总页码 小于 10
		if (this.totalPages <= 10) {
			// 没有前五后四原则
			//当前页码就是1 ,  末尾页码就是总页码
			beginPage = 1;
			endPage = this.totalPages;
		} else {
			// 总页码大于10 前五后四
			beginPage = this.pageNum - 5;// 11 - 5 =6
			endPage = this.pageNum + 4;//11 + 4 = 15
			// 排除 小于 0 大于总页码情况
			if (beginPage <= 0) {
				beginPage = 1;
				endPage = beginPage + 9;//1+9一共就是10
			}

			if (endPage >= this.totalPages) {
				endPage = this.totalPages;
				beginPage = this.totalPages - 9;//15-9 = 6
			}

		}
		// 定好 起始数字 末尾数字 计算
		this.pageBar = new int[endPage - beginPage + 1];//15 - 6 = 9+1 = 10页码
		int index = 0;
		for (int i = beginPage; i <= endPage; i++){//
			this.pageBar[index++] = i;
		}
		// 分页栏页码完成封装了!
		return this.pageBar;
	}

	public List<Product> getCustomers() {
		return customers;
	}

	public void setCustomers(List<Product> customers) {
		this.customers = customers;
	}

	public long getTotalCounts() {
		return totalCounts;
	}

	public void setTotalCounts(long totalCounts) {
		this.totalCounts = totalCounts;
	}

}
