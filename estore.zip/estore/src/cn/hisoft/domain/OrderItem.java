package cn.hisoft.domain;

public class OrderItem {
	private String orders_id;
	private String product_id;
	private int buynum;
	
	public String getOrders_id() {
		return orders_id;
	}

	public void setOrders_id(String orders_id) {
		this.orders_id = orders_id;
	}

	public String getProduct_id() {
		return product_id;
	}

	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}

	public int getBuynum() {
		return buynum;
	}

	public void setBuynum(int buynum) {
		this.buynum = buynum;
	}

	public OrderItem(){}

	@Override
	public String toString() {
		return "OrderItem [orders_id=" + orders_id + ", product_id="
				+ product_id + ", buynum=" + buynum + "]";
	}
	
	
}
