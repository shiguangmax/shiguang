package cn.hisoft.domain;

public class buycar {
	private String user_id;
	private String productid;
	private String buynum;
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String userId) {
		user_id = userId;
	}
	public String getProductid() {
		return productid;
	}
	public void setProductid(String productid) {
		this.productid = productid;
	}
	public String getBuynum() {
		return buynum;
	}
	public void setBuynum(String buynum) {
		this.buynum = buynum;
	}
	@Override
	public String toString() {
		return "buycar [buynum=" + buynum + ", productid=" + productid
				+ ", user_id=" + user_id + "]";
	}
	
}
