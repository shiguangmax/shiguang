package cn.hisoft.domain;

import java.util.Date;

public class Orders {
	private String id;
	private double totalprice;
	private String receiverinfor;
	private int paystate;
	private Date createtime;
	private String user_id;
	
	public Orders(){}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public double getTotalprice() {
		return totalprice;
	}

	public void setTotalprice(double totalprice) {
		this.totalprice = totalprice;
	}

	public String getReceiverinfor() {
		return receiverinfor;
	}

	public void setReceiverinfor(String receiverinfor) {
		this.receiverinfor = receiverinfor;
	}

	public int getPaystate() {
		return paystate;
	}

	public void setPaystate(int paystate) {
		this.paystate = paystate;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	@Override
	public String toString() {
		return "Orders [id=" + id + ", totalprice=" + totalprice
				+ ", receiverinfor=" + receiverinfor + ", paystate=" + paystate
				+ ", createtime=" + createtime + ", user_id=" + user_id + "]";
	};
	
	
}
