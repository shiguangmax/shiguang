package cn.hisoft.serviceImpl;

import java.util.List;

import cn.hisoft.dao.SearchProductDao;
import cn.hisoft.daoImpl.SearchProductDaoImpl;
import cn.hisoft.domain.Product;
import cn.hisoft.service.SearchProductService;

public class SearchProductServiceImpl implements SearchProductService {

	SearchProductDao searchProductDao=new SearchProductDaoImpl();
	
	@Override
	public List<Product> queryProduct(Product product) {
		return searchProductDao.queryProduct(product);
		
	}

}
