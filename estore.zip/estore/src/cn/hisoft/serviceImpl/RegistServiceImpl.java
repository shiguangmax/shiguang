package cn.hisoft.serviceImpl;


import cn.hisoft.dao.IRegistDao;
import cn.hisoft.daoImpl.RegistDaoImpl;
import cn.hisoft.domain.User;
import cn.hisoft.service.IRegistService;


/*
 * 许冠辉
 */
public class RegistServiceImpl implements IRegistService {
     IRegistDao dao = new RegistDaoImpl();
	
	@Override
	public boolean checkUser(User user) {
	User hasUser = dao.queryUserBytel(user);
	if (hasUser == null) {
		dao.regist(user);
		return true;
	}
		return false;
	}

}
