package cn.hisoft.serviceImpl;



import java.util.List;
import java.util.Map;

import cn.hisoft.dao.IOrdersDao;
import cn.hisoft.daoImpl.IOrdersDaoImpl;
import cn.hisoft.domain.Orders;
import cn.hisoft.domain.Product;
import cn.hisoft.service.IOrderService;


public class IOrderServiceImpl implements IOrderService {

	IOrdersDao orderDao = new IOrdersDaoImpl();

	public List<Orders> allOrdersInformation(String user_id){
		List<Orders> ordersInformation = orderDao.allOrdersInformation(user_id);
		return ordersInformation;
	}
	
	public Map<String, List<Product>> allProductInformationByOrders(String user_id){
		
		Map<String, List<Product>> productMap = orderDao.allProductInformationByOrders(allOrdersInformation(user_id));
		return productMap;
	}

	@Override
	public void deleteOrderByOrderId(String order_id) {
		orderDao.deleteOrderByOrderId(order_id);
	}
}
