package cn.hisoft.serviceImpl;




import cn.hisoft.dao.ILoginDao;
import cn.hisoft.daoImpl.LoginDaoImpl;
import cn.hisoft.domain.User;
import cn.hisoft.service.LoginService;

public class LoginServiceImpl implements LoginService {
	ILoginDao userdao = new LoginDaoImpl();

	@Override
	public User queryUserById(User user) {
		return userdao.queryUserById(user);
	}

}
