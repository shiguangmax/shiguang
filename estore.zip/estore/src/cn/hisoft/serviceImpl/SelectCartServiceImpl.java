package cn.hisoft.serviceImpl;

import java.util.List;

import cn.hisoft.dao.ISelectCartDao;
import cn.hisoft.daoImpl.SelectCartDaoImpl;
import cn.hisoft.domain.Orders;
import cn.hisoft.domain.Product;
import cn.hisoft.domain.buycar;
import cn.hisoft.domain.buycarProduct;
import cn.hisoft.service.ISelectCartService;

public class SelectCartServiceImpl implements ISelectCartService {
		ISelectCartDao selectCartdao = new SelectCartDaoImpl();
	@Override
	public List<buycarProduct> selectCart(String id) {
		
		return selectCartdao.selectCart(id);
	}
	@Override
	public void delCart(String id) {
		selectCartdao.delCart(id);
	}
	@Override
	public List<Product> selectProduct() {
		return selectCartdao.selectProduct();
	}
	@Override
	public Product selectOneProduct(String productid) {
		return selectCartdao.selectOneProduct(productid);
	}
	@Override
	public void buyProduct(String user_id, String productid) {
		buycar buySelectProduct = selectCartdao.buySelectProduct(user_id, productid);
		System.out.println(buySelectProduct);
		if(buySelectProduct==null){
		selectCartdao.buyProduct(user_id,productid);
		}else{
			selectCartdao.buyProductNum(user_id,productid);
		}
	}
	@Override
	public void buildOrder(List<buycarProduct> list, Orders order) {
		int flag = selectCartdao.buildorder(list,order);
		if(flag!=0){
			for (buycarProduct orderitem : list) {
				System.out.println(orderitem);
				selectCartdao.addOrderItem(order.getId(),orderitem);
			}
			selectCartdao.delAllCart(order.getUser_id());
		}
	}

}
