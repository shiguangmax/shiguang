package cn.hisoft.serviceImpl;

import java.util.List;

import cn.hisoft.dao.ProductAddDao;
import cn.hisoft.daoImpl.ProductAddDaoImpl;
import cn.hisoft.domain.Pagenation;
import cn.hisoft.domain.Product;
import cn.hisoft.service.ProductService;



public class ProductServiceImpl implements  ProductService{

	@Override
	public boolean ProductAddService(Product product) { //添加数据
		ProductAddDao productAddDao = new ProductAddDaoImpl();
		return productAddDao.ProductAddDao(product);

	}

	@Override
	public List<Product> selectServiceShangPin() {    //查看所有商品信息   此方法已经废弃没用
		ProductAddDao productSelectDao = new ProductAddDaoImpl();
		
		return productSelectDao.selectDaoShangpin();
	}
	
	public Product findAllCustomerById(String id) {    //根据id查询表格信息进行回显-商品详情
		ProductAddDao productSelectDao = new ProductAddDaoImpl();
		return productSelectDao.findAllCustomerById(id);
	}

	@Override
	public void findAllCustomerspagenation(Pagenation pagenation) {    //分页查询
		//查询出来所有数据
		ProductAddDao productSelectDao = new ProductAddDaoImpl();
				pagenation.setTotalCounts(productSelectDao.getTotalCounts());//到数据库中查总条数
				pagenation.setCustomers(productSelectDao.getCustomers(pagenation.getStartIndex() , pagenation.getPageSize()));
	}
	
	
	
	
	
	
	
	/*
	 * 这可是商品分类查询
	 * 分页查询 纯属敲着玩
	 * 哈哈哈
	 * 
	 */
	
	public void findAllCustomerspagenationFenYe(Pagenation pagenation,Product product) {    //分页查询
		//查询出来所有数据
		ProductAddDao productSelectDao = new ProductAddDaoImpl();
				pagenation.setTotalCounts(productSelectDao.getTotalCountsFenYe(product));//到数据库中查总条数
				pagenation.setCustomers(productSelectDao.getCustomersFenYe(pagenation.getStartIndex() , pagenation.getPageSize(),product));
	}




	
	
	
	
	
	
	
	
	
	
	
	
}
