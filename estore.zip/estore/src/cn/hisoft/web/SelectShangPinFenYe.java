package cn.hisoft.web;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import cn.hisoft.domain.Pagenation;
import cn.hisoft.domain.Product;
import cn.hisoft.service.ProductService;
import cn.hisoft.serviceImpl.ProductServiceImpl;


public class SelectShangPinFenYe extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");

		

		try {
			Product product = new Product();
			
			Pagenation pagenation = new Pagenation();
			BeanUtils.populate(pagenation, request.getParameterMap());
			// 调用业务层
			ProductService SelectService = new ProductServiceImpl();
			
			String category = request.getParameter("fenye");
			product.setCategory(category);
			
		//	System.out.println(category);
			
			/*
			 * 判断要查询什么类型的商品
			 */
			
			if(true){
				SelectService.findAllCustomerspagenationFenYe(pagenation,product);
				
				request.setAttribute("pagenation", pagenation);
                request.getRequestDispatcher("/XianShiFenYe.jsp").forward(request, response);
						
			}
			
			
			
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}

	}

}
