package cn.hisoft.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;

import cn.hisoft.Utils.MD5Utils;
import cn.hisoft.domain.User;
import cn.hisoft.service.LoginService;
import cn.hisoft.serviceImpl.LoginServiceImpl;

public class LoginServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		
		User user = new User();
		Map map = request.getParameterMap();
		String[] remember = request.getParameterValues("remmber");
		
		try {
			BeanUtils.populate(user, map);
			user.setPassword(MD5Utils.getPWD(user.getPassword()));
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
			
		LoginService loginService = new LoginServiceImpl();
		User hasUser = loginService.queryUserById(user);

		
		if (hasUser==null) {
			request.setAttribute("loginMes", "用户名或密码错误");
			request.setAttribute("remUser", remember[0]);
			request.setAttribute("user",user);
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		} else {
			HttpSession session = request.getSession();
			session.setAttribute("user",hasUser);
			request.getRequestDispatcher("/index.jsp").forward(request, response);
		}
		
	}

}
