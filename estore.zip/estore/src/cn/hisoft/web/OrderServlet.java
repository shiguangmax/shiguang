package cn.hisoft.web;

import java.io.IOException;
import java.util.List;
import java.util.Map;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.hisoft.domain.Orders;
import cn.hisoft.domain.Product;
import cn.hisoft.domain.User;
import cn.hisoft.service.IOrderService;
import cn.hisoft.serviceImpl.IOrderServiceImpl;

public class OrderServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		User user = (User)request.getSession().getAttribute("user");
		
		IOrderService orderService = new IOrderServiceImpl();
		
		List<Orders> allOrdersInformation = orderService.allOrdersInformation(user.getId());
		request.setAttribute("ordersList", allOrdersInformation);
		
		Map<String, List<Product>> allProductInformationByOrders = orderService.allProductInformationByOrders(user.getId());
		request.setAttribute("productInforByOrdersId", allProductInformationByOrders);
		
		String nickname = user.getNickname();
		request.setAttribute("nickname", nickname);
		
		request.getRequestDispatcher("/order.jsp").forward(request, response);
	}

}
