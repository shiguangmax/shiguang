package cn.hisoft.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.hisoft.domain.User;
import cn.hisoft.service.ISelectCartService;
import cn.hisoft.serviceImpl.SelectCartServiceImpl;

public class BuyProductServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User user = (User) request.getSession().getAttribute("user");
		 String productid = request.getParameter("productid");
		 ISelectCartService selectcartservice = new SelectCartServiceImpl();
		 selectcartservice.buyProduct(user.getId(),productid);
		 request.getRequestDispatcher("/buyorcart.jsp").forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
