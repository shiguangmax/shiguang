package cn.hisoft.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.hisoft.domain.Product;
import cn.hisoft.service.ISelectCartService;
import cn.hisoft.serviceImpl.SelectCartServiceImpl;

public class SelectOneProductServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String productid = request.getParameter("id");
		ISelectCartService selectcartservice = new SelectCartServiceImpl();
		Product product = selectcartservice.selectOneProduct(productid);
		request.setAttribute("product",product );
		request.getRequestDispatcher("/product_detail.jsp").forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
