package cn.hisoft.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.PageContext;

import org.apache.taglibs.standard.lang.jstl.test.PageContextImpl;

import cn.hisoft.domain.Orders;
import cn.hisoft.domain.User;
import cn.hisoft.domain.buycarProduct;
import cn.hisoft.service.ISelectCartService;
import cn.hisoft.serviceImpl.SelectCartServiceImpl;

public class BuildOrderServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		Orders order = new Orders();
		User user = (User) request.getSession().getAttribute("user");
		ISelectCartService selectcartservice = new SelectCartServiceImpl();
		List<buycarProduct> list = selectcartservice.selectCart(user.getId());
		Double totalprice = 0.0;
		for (buycarProduct bcp : list) {
			totalprice=totalprice+(bcp.getEstoreprice()*bcp.getBuynum());
		}
		String receiverinfo = request.getParameter("receiverinfo");
		String ordersid = UUID.randomUUID().toString();
		order.setTotalprice(totalprice);
		order.setUser_id(user.getId());
		order.setReceiverinfor(receiverinfo);
		order.setId(ordersid);
		order.setCreatetime(new Date(new java.util.Date().getTime()));
		selectcartservice.buildOrder(list,order);
		response.sendRedirect(request.getContextPath()+"/orderServlet");
	}

}
