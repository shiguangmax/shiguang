package cn.hisoft.web;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import cn.hisoft.Utils.MD5Utils;
import cn.hisoft.domain.User;
import cn.hisoft.service.IRegistService;
import cn.hisoft.serviceImpl.RegistServiceImpl;

import com.sun.org.apache.commons.beanutils.BeanUtils;

/*
 * 许冠辉
 */
public class RegistServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");

		Map<String, String[]> parameterMap = request.getParameterMap();
		User user = new User();
		try {
			BeanUtils.populate(user, parameterMap);
			String repassword = request.getParameter("repassword");

			user.setId(UUID.randomUUID().toString());
			user.setPassword(MD5Utils.getPWD(user.getPassword()));
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}

		IRegistService registService = new RegistServiceImpl();
		boolean checkUser = registService.checkUser(user);
		if (checkUser){
			response.sendRedirect(request.getContextPath()+"/login.jsp");
		}else{
			request.setAttribute("userMes", "该用户已存在");
			request.getRequestDispatcher("/regist.jsp").forward(request, response);
		}
	}
}
