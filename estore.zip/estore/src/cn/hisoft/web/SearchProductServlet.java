package cn.hisoft.web;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import cn.hisoft.domain.Product;
import cn.hisoft.service.SearchProductService;
import cn.hisoft.serviceImpl.SearchProductServiceImpl;

public class SearchProductServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		
		String search = request.getParameter("search");
		Product product = new Product();
		product.setName(search);
		product.setCategory(search);
		
		SearchProductService searchProductService=new SearchProductServiceImpl();
		List<Product> productList=searchProductService.queryProduct(product);
		
		request.setAttribute("productList", productList);
		request.getRequestDispatcher("/fuzzySearchProduct.jsp").forward(request, response);

	}

}
