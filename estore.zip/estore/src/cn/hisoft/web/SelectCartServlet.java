package cn.hisoft.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.hisoft.domain.Product;
import cn.hisoft.domain.User;
import cn.hisoft.domain.buycar;
import cn.hisoft.domain.buycarProduct;
import cn.hisoft.service.ISelectCartService;
import cn.hisoft.serviceImpl.SelectCartServiceImpl;

public class SelectCartServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User user = (User) request.getSession().getAttribute("user");
		if(user==null){
			response.sendRedirect(request.getContextPath()+"/login.jsp");
			return;
		}
		ISelectCartService selectcartservice = new SelectCartServiceImpl();
		System.out.println(user.getId());
		List<buycarProduct> list = selectcartservice.selectCart(user.getId());
		request.setAttribute("list", list);
		request.getRequestDispatcher("/cart.jsp").forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	}

}
