package cn.hisoft.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.hisoft.domain.Product;
import cn.hisoft.service.ProductService;
import cn.hisoft.serviceImpl.ProductServiceImpl;


public class FindProductDetailsServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
					doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	      request.setCharacterEncoding("utf-8");
	      response.setContentType("text/html;charset=utf-8");		
		// 根据id来查询
	      ProductService SelectService = new ProductServiceImpl();
		 String id = request.getParameter("id");// 获取id
		 Product oldCustomer = SelectService.findAllCustomerById(id);
			//根据id查询到的信息进行回显 
			request.setAttribute("xiangQing", oldCustomer);
			request.getRequestDispatcher("/product_detail.jsp").forward(request, response);
	}

}
