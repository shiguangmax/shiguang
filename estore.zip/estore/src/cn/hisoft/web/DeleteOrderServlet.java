package cn.hisoft.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.hisoft.service.IOrderService;
import cn.hisoft.serviceImpl.IOrderServiceImpl;

public class DeleteOrderServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String order_id = request.getParameter("order_id");
		
		IOrderService orderService=new IOrderServiceImpl();
		orderService.deleteOrderByOrderId(order_id);
		request.getRequestDispatcher("/orderServlet").forward(request, response);
	}

}
