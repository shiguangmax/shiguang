package cn.hisoft.web;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import cn.hisoft.domain.Pagenation;
import cn.hisoft.service.ProductService;
import cn.hisoft.serviceImpl.ProductServiceImpl;


public class SelectShangPin extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
					doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		 request.setCharacterEncoding("utf-8");
	      response.setContentType("text/html;charset=utf-8");
		
		try {
			Pagenation pagenation = new Pagenation();
			BeanUtils.populate(pagenation, request.getParameterMap());
			// 调用业务层
			ProductService SelectService = new ProductServiceImpl();
			SelectService.findAllCustomerspagenation(pagenation);

			request.setAttribute("pagenation", pagenation);

			request.getRequestDispatcher("/product.jsp").forward(
					request, response);

		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		
		
		
		
		
		
		
		
		
/*	      request.setCharacterEncoding("utf-8");
	      response.setContentType("text/html;charset=utf-8");
	      
	      ProductService SelectService = new ProductServiceImpl();
	      List<Product> cs = SelectService.selectServiceShangPin();
			// 把查询到的数据写入到浏览器中去
			request.setAttribute("AllShangPin", cs);
			// 转发到显示的页面
			request.getRequestDispatcher("/product.jsp").forward(request,
					response);*/

	}

}
