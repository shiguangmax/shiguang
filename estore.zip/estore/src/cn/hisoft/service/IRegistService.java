package cn.hisoft.service;

import cn.hisoft.domain.User;

public interface IRegistService {

	boolean checkUser(User user);

}
