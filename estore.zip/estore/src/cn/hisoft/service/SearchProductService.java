package cn.hisoft.service;

import java.util.List;

import cn.hisoft.domain.Product;


public interface SearchProductService {

	List<Product> queryProduct(Product product);

}
