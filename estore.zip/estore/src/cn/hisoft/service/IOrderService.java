package cn.hisoft.service;

import java.util.List;
import java.util.Map;

import cn.hisoft.domain.Orders;
import cn.hisoft.domain.Product;

public interface IOrderService {

	List<Orders> allOrdersInformation(String user_id);
	Map<String, List<Product>> allProductInformationByOrders(String user_id);
	void deleteOrderByOrderId(String order_id);

}
