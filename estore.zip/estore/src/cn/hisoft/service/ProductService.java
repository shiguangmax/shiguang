package cn.hisoft.service;

import java.util.List;

import cn.hisoft.domain.Pagenation;
import cn.hisoft.domain.Product;


public interface ProductService {
	 boolean ProductAddService (Product product);//添加数据

	List<Product> selectServiceShangPin();//查看所有商品
	 		
	Product	findAllCustomerById (String id);//根据id做单个回显-商品详情

	void findAllCustomerspagenation(Pagenation pagenation);
	/*
	 * 商品分类查询
	 * 
	 */
	

	void findAllCustomerspagenationFenYe(Pagenation pagenation, Product product);
	


	
	
	

	
}
