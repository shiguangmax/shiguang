package cn.hisoft.service;

import cn.hisoft.domain.User;

public interface LoginService {
	
	User queryUserById(User user);
}
