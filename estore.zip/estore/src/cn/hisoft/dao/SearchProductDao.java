package cn.hisoft.dao;

import java.util.List;

import cn.hisoft.domain.Product;

public interface SearchProductDao {

	List<Product> queryProduct(Product product);

}
