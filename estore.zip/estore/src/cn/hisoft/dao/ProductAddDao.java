package cn.hisoft.dao;

import java.util.List;

import cn.hisoft.domain.Product;

public interface ProductAddDao {
	boolean ProductAddDao (Product product);//添加数据

	List<Product> selectDaoShangpin();//查询所有商品
	
	Product findAllCustomerById(String id);

	long getTotalCounts();//分页

	List<Product> getCustomers(int startIndex, int pageSize);//分页
	
	
	/*
	 * 
	 * 商品分类查询
	 * 
	 */

	long getTotalCountsFenYe(Product product);//分页传入商品类型

	

	List<Product> getCustomersFenYe(int startIndex, int pageSize, Product product);//获取分类查询商品的信息

	
}
