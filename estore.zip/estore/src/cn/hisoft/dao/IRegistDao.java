package cn.hisoft.dao;

import cn.hisoft.domain.User;

public interface IRegistDao {
	
	public User queryUserBytel(User user);

	public void regist(User user);
	

}
