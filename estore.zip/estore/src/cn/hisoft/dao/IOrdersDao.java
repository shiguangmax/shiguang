package cn.hisoft.dao;

import java.util.List;
import java.util.Map;

import cn.hisoft.domain.Orders;
import cn.hisoft.domain.Product;

public interface IOrdersDao {
	
	List<Orders> allOrdersInformation(String user_id);
	Map<String, List<Product>> allProductInformationByOrders(
			List<Orders> ordersList);
	void deleteOrderByOrderId(String order_id);

}
