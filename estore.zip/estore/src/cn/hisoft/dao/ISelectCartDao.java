package cn.hisoft.dao;

import java.util.List;

import cn.hisoft.domain.Orders;
import cn.hisoft.domain.Product;
import cn.hisoft.domain.buycar;
import cn.hisoft.domain.buycarProduct;

public interface ISelectCartDao {
	/**
	 * 查看购物车商品
	 * @param id
	 * @return list
	 */
	List<buycarProduct> selectCart(String id);
	/**
	 * 删除购物车单项商品
	 * @param id
	 */
	void delCart(String id);
	/**
	 * 查询所有商品
	 */
	List<Product> selectProduct();
	/**
	 * 查询单个商品信息
	 * @param productid
	 * @return
	 */
	Product selectOneProduct(String productid);
	/**
	 * 查询购物车商品重复
	 * @param userId
	 * @param productid
	 * @return
	 */
	buycar buySelectProduct(String user_id, String productid);
	/**
	 * 添加商品到购物车
	 * @param userId
	 * @param productid
	 */
	void buyProduct(String user_id, String productid);
	/**
	 * 添加购物车物品数量
	 * @param userId
	 * @param productid
	 */
	void buyProductNum(String user_id, String productid);
	/**
	 * 生成订单
	 * @param list
	 * @param order
	 */
	int buildorder(List<buycarProduct> list, Orders order);
	/**
	 * 生成中间表
	 * @param id
	 * @param orderitem
	 */
	void addOrderItem(String id, buycarProduct orderitem);
	/**
	 * 订单成功后删除购物车
	 * @param user_id
	 */
	void delAllCart(String user_id);


}
