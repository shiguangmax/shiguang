package cn.hisoft.dao;

import cn.hisoft.domain.User;

public interface ILoginDao {
	/*
	 * 登陆
	 */
    

	User queryUserById(User user);
	
}
