package cn.hisoft.filter;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import cn.hisoft.domain.Product;
import cn.hisoft.service.ProductService;
import cn.hisoft.serviceImpl.ProductServiceImpl;



public class Upload extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
				doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		      request.setCharacterEncoding("utf-8");
		      response.setContentType("text/html;charset=utf-8");
		Product c = new Product();
		//判断的上传类型是不是enctype="multipart/form-data"
		boolean content = ServletFileUpload.isMultipartContent(request);
		if( !content){
			throw new RuntimeException("不是一个有效的上传类型！");
		}
		
		//上传核心解析类
		DiskFileItemFactory factory = new DiskFileItemFactory();
		//创建上传对象
		ServletFileUpload upload = new ServletFileUpload(factory);
		
		//设置上传文件名的字符集
		upload.setHeaderEncoding("utf-8");

		//设置上传的大小
		upload.setFileSizeMax(1024 * 1024 * 20);
		upload.setSizeMax(1024 * 1024 * 50);
	
		//解析request
		try {

			
			//获取上传请求，但是上传类型，普通类型 都封装到list中
			//自动封装FileItem对象中
			List<FileItem> list = upload.parseRequest(request);
			
			for(FileItem item : list ){
				//判断如果是普通类型就获取普通类型的 值
				if(item.isFormField()){
					String name = item.getFieldName();//获取普通类型的属性名    == name

					String value = item.getString("utf-8");//获取普通类型的输入的值
					
			        Map<Object, Object> map=new HashMap<Object, Object>(); 
			        
			        map.put(name, value);
			        
			        c.setId(UUID.randomUUID().toString());// 解决插入客户不会出现主键冲突
			        
			        BeanUtils.populate(c, map);
			    //    System.out.println("有没有值"+c);

					
			        
			        
				//	System.out.println("普通类型的属性名: "+name);
				//	System.out.println("普通类型的输入的值: "+value);
					
				}else{
					//上传文件类型
			//  	String fieldName = item.getFieldName();
					String name = item.getName();//获取上传文件的真实文件名
			//		String contentType = item.getContentType();
					
					
				    String prefix=name.substring(name.lastIndexOf("."));// 解决插入商品名字重复问题

					 name=(UUID.randomUUID().toString()+prefix);// 解决插入商品名字重复问题
					 
				//	 System.out.println("文件后缀"+prefix2);
				//	System.out.println("上传属性值： "+fieldName);//上传属性值
				//	System.out.println("上传的真实名字： "+name);//上传的真实名字
				//	System.out.println("上传类型： "+contentType);//上传类型
					
					try {
						//文件写入到服务器
						//tomcat提供了write方法，写入
						String realPath = this.getServletContext().getRealPath("/images6");
						
							c.setImgurl("images6"+"/"+name);


						File file = new File(realPath);
						if( ! file.exists()){
							file.mkdir();
						}
						item.write(new File(file ,name ));
						item.delete();//清除缓存

						
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
		
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		ProductService AddService = new ProductServiceImpl();
		boolean addService = AddService.ProductAddService(c);
		
		if(addService){
			
			// 把查询到的数据写入到浏览器中去
			// request.setAttribute("message", c);
			request.getRequestDispatcher("/selectShangPin").forward(request,response);
				

		}else{
			response.getWriter().print("no");
		}
		
		
		
		
	}

}

